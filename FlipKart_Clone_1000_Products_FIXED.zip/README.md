# FlipKart Clone - 1000 Product Demo

Upload BOTH `index.html` and `products.js` to the same GitHub repository root, then enable GitHub Pages.

The store contains 1000 demo products, each priced at ₹250 or less. Product images are embedded as local SVG data, so the catalog is not dependent on an image CDN.

UPI ID configured:
BHARATPE2F0D0A6C3B74273@unitype

Checkout:
1. Customer selects Buy Now / Cart.
2. Total amount is calculated automatically.
3. A UPI payment URI is generated with the exact amount.
4. A QR code is shown.
5. Customer can open a UPI app or scan the QR.
6. Customer can send order confirmation on WhatsApp.

Important: this is a static GitHub Pages checkout. It does not verify whether a UPI payment actually succeeded. Confirm payment manually on your UPI/merchant app before fulfilling an order.
