# FlipKart Mini Store Demo

- 1000 demo products, all priced at or below ₹250.
- Search, category filters, cart, Buy Now.
- UPI checkout generates a dynamic UPI payment URI using the configured UPI ID.
- QR is generated from the UPI URI using a public QR image service.

## GitHub Pages
Upload `index.html` to a GitHub repository and enable GitHub Pages.

## Important
This is a front-end demo. A successful UPI payment cannot be verified securely by static GitHub Pages alone. For real orders, use a licensed payment gateway/UPI provider with server-side payment verification and webhooks.
